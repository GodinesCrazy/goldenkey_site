Hola {{nombre}},

¡Gracias por usar Niche Finder GPT!

Adjunto encontrarás tu informe gratuito con una idea de nicho validada y los primeros pasos para empezar.

Si quieres un análisis más profundo con 5-10 nichos, un plan de contenidos y estrategias de monetización, considera nuestro Informe Pro.

¡Mucha suerte con tu proyecto!

-- GoldenKey Studios